
import json

def handler(event, context):
    bot_type = event.get("bot", "scalping")
    profile = event.get("profile", "moderado")

    return {
        'statusCode': 200,
        'body': json.dumps(f"Bot {bot_type} activado para perfil {profile}")
    }
